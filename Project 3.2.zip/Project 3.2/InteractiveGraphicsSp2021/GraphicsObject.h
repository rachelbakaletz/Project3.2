#pragma once
#ifndef ABSTRACT_GRAPHICS_OBJECT
#define ABSTRACT_GRAPHICS_OBJECT

#include "BaseObject.h"
#include "ReferenceFrame.h"
#include "AbstractTexture.h"
class AbstractAnimation;
#include "AbstractMesh.h"
#include <vector>
#include "BoundingSphere.h"
using std::vector;

class GraphicsObject : 
   public BaseObject
{
protected:

   AbstractAnimation* _animation;
   vector<AbstractMesh*> _meshes;

public:
   ReferenceFrame frame;
   bool isVisible;
   BoundingSphere boundingSphere; 

public:
   GraphicsObject() : _animation(nullptr), isVisible(true){
   
       boundingSphere.radius = 3.2f; 
   }

   virtual ~GraphicsObject();

   virtual inline AbstractMesh* GetMesh(int index)
   {
      return _meshes[index];
   }

   virtual inline vector<AbstractMesh*>& GetMeshes() {
      return _meshes;
   }

   inline void AddMesh(AbstractMesh* mesh)
   {
      _meshes.push_back(mesh);
   }

   virtual inline void SetAnimation(AbstractAnimation* animation);

   virtual void Update(double elapsedSeconds);

   virtual void SendToGPU();
};
#endif
