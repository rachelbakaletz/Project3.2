#pragma once
#include <glad/glad.h>
#include <glm\glm.hpp>
#include "GeometricPlane.h"
#include "ReferenceFrame.h"
class ViewingFrustrum
{
protected:
	float frontWidth;
	float frontHeight;
	float backWidth;
	float backHeight;
	float depth;

public:

	GeometricPlane planes[6];
	ReferenceFrame frame; 
	
	ViewingFrustrum() {}

	ViewingFrustrum(float fw, float fh, float bw, float bh, float depth) {
		fw = 0;
		fh = 0;
		bw = 0;
		bh = 0;
		depth = 0;

		Create();
	};

	virtual inline void Set(float fw, float fh, float bw, float bh, float depth) {
	}

	virtual inline void Create() {
		float halfFrontWidth = frontWidth / 2;
		float halfFrontHeight = frontHeight / 2;
		float halfBackWidth = backWidth / 2;
		float halfBackHeight = backHeight / 2;

		glm::vec3 ulf = { halfFrontWidth, halfFrontHeight, 0 };
		glm::vec3 llf = { halfFrontWidth, -halfFrontHeight, 0 };
		glm::vec3 lrf = { -halfFrontWidth, -halfFrontHeight, 0 };
		glm::vec3 urf = { -halfFrontWidth,  halfFrontHeight, 0 };
		glm::vec3 ulb = { halfBackWidth,  halfBackHeight, depth };
		glm::vec3 llb = { halfBackWidth, -halfBackHeight, depth };
		glm::vec3 lrb = { -halfBackWidth, -halfBackHeight, depth };
		glm::vec3 urb = { -halfBackWidth,  halfBackHeight, depth };

		glm::vec3 F1 = frame.Transform(ulf); 
		glm::vec3 F2 = frame.Transform(llf);
		glm::vec3 F3 = frame.Transform(lrf);
		glm::vec3 F4 = frame.Transform(urf);

		glm::vec3 B1 = frame.Transform(ulb);
		glm::vec3 B2 = frame.Transform(llb);
		glm::vec3 B3 = frame.Transform(lrb);
		glm::vec3 B4 = frame.Transform(urb);

		
		planes[0].Set(frame.GetZAxis(), F3);
		planes[1].Set(-frame.GetZAxis(), B2);
		planes[2].Set(F1, F2, B2);
		planes[3].Set(B4, B3, F3);
		planes[4].Set(F1, B1, B4);
		planes[5].Set(B2, F2, F3);
	}

	virtual inline bool HasPointsInside(glm::vec3 point) {
		for (int i = 0; i <= 5;)
		{
			if (!planes[i].IsPointInFront(point))
			{
				return false; 
			}

			i++;
		}

		return true;
	}

	virtual inline bool HasSphereInside(BoundingSphere sphere) {
		for (int i = 0; i <= 5; i++)
		{
			if (!planes[i].IsSphereInFront(sphere))
			{
				return false;
			}
		}

		return true;

	}// end HasSphereInside


};

