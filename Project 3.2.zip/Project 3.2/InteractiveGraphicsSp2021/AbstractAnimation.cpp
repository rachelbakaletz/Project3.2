#include "AbstractAnimation.h"
#include "GraphicsObject.h"

void AbstractAnimation::SetObject(GraphicsObject* object)
{
   _object = object;
}
