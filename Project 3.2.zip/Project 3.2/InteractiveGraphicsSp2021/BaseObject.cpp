#include "BaseObject.h"

// The definition of the static object
stringstream BaseObject::_log;
