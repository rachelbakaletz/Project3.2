#pragma once
#include <glad/glad.h>
#include <glm\glm.hpp>
#include "BoundingSphere.h"

class GeometricPlane
{
protected:
	glm::vec3 N; 
	float d; 

public:
	GeometricPlane() {
		N = {0,0,0}; 
		d = 0.0; 
	}; 

	GeometricPlane(const glm::vec3& p1, const glm::vec3& p2, const glm::vec3& p3) {
		Set(p1, p2, p3); 
		
	}; 

	GeometricPlane(const glm::vec3& normal, const glm::vec3& p) {
		Set(normal, p); 

	};

	GeometricPlane(const glm::vec3& normal, float d) {
		N = normal; 
		d = d; 

	}; 

	virtual inline void Set(const glm::vec3& p1, const glm::vec3& p2, const glm::vec3& p3) {
		glm::vec3 v1; 
		v1 = p2 - p1; 
		
		glm::vec3 v2;
		v2 = p3 - p1;

		N = glm::normalize(glm::cross(v1, v2)); 
		d = -glm::dot(p1, N); 
	

	}

	virtual inline void Set(glm::vec3 normal, glm::vec3 p) {

		N = glm::normalize(normal); 

		d = -glm::dot(p, N); 
	}

	virtual inline bool IsPointInFront(glm::vec3 point) {

		float projection; 
		projection = glm::dot(point, N);

		return (projection + d) > 0; 
	}

	virtual inline bool IsSphereInFront(BoundingSphere sphere) {
		float projection = glm::dot(sphere.position, N); 

		return (projection + d + sphere.radius) > 0; 

	}

};

