#pragma once
#ifndef OGL_GRAPHICS_SYSTEM
#define OGL_GRAPHICS_SYSTEM

#include "GraphicsSystem.h"

class OGLGraphicsSystem :
    public GraphicsSystem
{
public:
   void Initialize();
};

#endif

